import { createHash } from "node:crypto";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { authRateLimits } from "@/db/schema";

export type RateLimitResult = {
  allowed: boolean;
  retryAfterSeconds: number;
};

export function isSameOriginRequest(request: Request) {
  const origin = request.headers.get("origin");
  const host = request.headers.get("x-forwarded-host")?.split(",")[0]?.trim() ?? request.headers.get("host");
  if (!origin || !host) return false;

  try {
    return new URL(origin).host.toLowerCase() === host.toLowerCase();
  } catch {
    return false;
  }
}

function anonymizedKey(scope: string, address: string) {
  return createHash("sha256").update(`${scope}:${address}`).digest("hex");
}

export function getClientAddress(headers: Headers) {
  const address =
    headers.get("x-real-ip") ??
    headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    "unknown-client";
  return address.slice(0, 120) || "unknown-client";
}

export async function enforceRateLimit(options: {
  scope: string;
  headers: Headers;
  limit: number;
  windowMilliseconds: number;
}): Promise<RateLimitResult> {
  const now = new Date();
  const windowStart = new Date(now.getTime() - options.windowMilliseconds);
  const key = anonymizedKey(options.scope, getClientAddress(options.headers));

  const [record] = await db
    .insert(authRateLimits)
    .values({ key, attempts: 1, windowStartedAt: now })
    .onConflictDoUpdate({
      target: authRateLimits.key,
      set: {
        attempts: sql`CASE WHEN ${authRateLimits.windowStartedAt} <= ${windowStart} THEN 1 ELSE ${authRateLimits.attempts} + 1 END`,
        windowStartedAt: sql`CASE WHEN ${authRateLimits.windowStartedAt} <= ${windowStart} THEN ${now} ELSE ${authRateLimits.windowStartedAt} END`,
      },
    })
    .returning({
      attempts: authRateLimits.attempts,
      windowStartedAt: authRateLimits.windowStartedAt,
    });

  const retryAfterSeconds = Math.max(
    1,
    Math.ceil((record.windowStartedAt.getTime() + options.windowMilliseconds - now.getTime()) / 1000),
  );

  return {
    allowed: record.attempts <= options.limit,
    retryAfterSeconds,
  };
}
