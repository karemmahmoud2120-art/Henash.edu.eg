import { auth } from "@/auth";

export async function requireAdminSession() {
  const session = await auth();
  return session?.user?.id && session.user.role === "admin" ? session : null;
}

export { isSameOriginRequest } from "@/lib/auth-security";

export function forbiddenJson(message = "هذا الإجراء متاح لمدير المنصة فقط.") {
  return Response.json(
    { message },
    { status: 403, headers: { "Cache-Control": "no-store" } },
  );
}
