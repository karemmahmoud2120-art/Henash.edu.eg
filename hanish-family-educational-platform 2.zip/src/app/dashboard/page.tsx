import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { DashboardClient } from "@/app/auth-ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "حساب الطالب | منصة حنيش التعليمية",
  description: "لوحة الحساب الخاصة بطلاب المنصة التعليمية لأبناء عائلة حنيش.",
};

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");
  if (session.user.role === "admin") redirect("/admin");

  return (
    <DashboardClient
      name={session.user.name || session.user.username}
      username={session.user.username}
      grade={session.user.grade}
    />
  );
}
