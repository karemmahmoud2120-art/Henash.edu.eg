import type { Metadata } from "next";
import AuthPage from "@/app/auth-ui";

export const metadata: Metadata = {
  title: "إنشاء حساب طالب | منصة حنيش التعليمية",
  description: "أنشئ حسابًا تعليميًا مجانيًا لطلاب المرحلة الابتدائية والإعدادية والثانوية.",
};

export default function RegisterPage() {
  return <AuthPage mode="register" />;
}
