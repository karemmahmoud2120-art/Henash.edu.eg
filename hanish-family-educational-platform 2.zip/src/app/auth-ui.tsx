"use client";

import "./auth-ui.css";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { useState, type FormEvent } from "react";

type AuthMode = "login" | "register";

const grades = [
  "الصف الأول الابتدائي",
  "الصف الثاني الابتدائي",
  "الصف الثالث الابتدائي",
  "الصف الرابع الابتدائي",
  "الصف الخامس الابتدائي",
  "الصف السادس الابتدائي",
  "الصف الأول الإعدادي",
  "الصف الثاني الإعدادي",
  "الصف الثالث الإعدادي",
  "الصف الأول الثانوي",
  "الصف الثاني الثانوي",
  "الصف الثالث الثانوي",
];

function BrandMark() {
  return (
    <Link className="brand auth-brand" href="/" aria-label="العودة إلى المنصة التعليمية">
      <span className="brand-mark"><span>ح</span><i /></span>
      <span className="brand-copy"><strong>حنيش</strong><small>منصة تعليمية</small></span>
    </Link>
  );
}

function ArrowIcon({ left = false }: { left?: boolean }) {
  return (
    <svg className={left ? "auth-arrow-left" : ""} width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M19 12H5m7 7-7-7 7-7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function AuthPage({ mode }: { mode: AuthMode }) {
  const router = useRouter();
  const isRegister = mode === "register";
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [grade, setGrade] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [notice, setNotice] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrorMessage("");
    setNotice("");

    const normalizedUsername = username.trim().toLowerCase();
    if (isRegister && password !== confirmPassword) {
      setErrorMessage("كلمتا المرور غير متطابقتين. راجعهما وحاول مرة أخرى.");
      return;
    }

    setIsSubmitting(true);
    try {
      if (isRegister) {
        const response = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            displayName,
            username: normalizedUsername,
            password,
            grade,
          }),
        });
        const result = (await response.json()) as { message?: string };
        if (!response.ok) throw new Error(result.message || "تعذّر إنشاء الحساب.");
      }

      const result = await signIn("credentials", {
        username: normalizedUsername,
        password,
        redirect: false,
        redirectTo: "/dashboard",
      });

      if (!result?.ok || result.error) {
        if (isRegister) {
          setNotice("تم إنشاء الحساب بنجاح. سجّل دخولك الآن باستخدام اسم المستخدم وكلمة المرور.");
          setIsSubmitting(false);
          router.push("/login");
          return;
        }
        throw new Error("اسم المستخدم أو كلمة المرور غير صحيحة.");
      }

      router.replace("/dashboard");
      router.refresh();
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "حدث خطأ غير متوقع. حاول مرة أخرى.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className={`auth-page ${isRegister ? "auth-page-register" : ""}`} dir="rtl">
      <aside className="auth-visual" aria-label="طلاب يتعلمون معًا">
        <div className="auth-visual-art">
          <Image
            src="/images/hanish-students.jpg"
            alt="أخ وأخته يتعلمان معًا"
            fill
            priority
            sizes="(max-width: 800px) 0vw, 50vw"
          />
          <span className="auth-photo-overlay" />
          <span className="auth-photo-sticker"><span>معًا</span><strong>نتعلّم</strong></span>
        </div>
        <div className="auth-visual-content">
          <BrandMark />
          <div className="auth-visual-copy">
            <span className="auth-visual-kicker"><i /> مكانك محفوظ بين أهلك</span>
            <h1>رحلتك التعليمية<br /><em>تبدأ من هنا.</em></h1>
            <p>حساب واحد يفتح لك باب المتابعة والمواد الدراسية لأبناء عائلة حنيش.</p>
            <div className="auth-visual-foot"><span>علمٌ يجمعنا</span><span>✳</span><span>خطوة نحو المستقبل</span></div>
          </div>
          <div className="auth-visual-copy-space" />
        </div>
      </aside>

      <section className="auth-panel">
        <div className="auth-panel-top"><BrandMark /><Link href="/">العودة للمنصة <ArrowIcon left /></Link></div>
        <div className="auth-card-wrap">
          <div className="auth-heading">
            <span className="auth-eyebrow"><i /> {isRegister ? "حساب طالب جديد" : "مرحبًا بك في المنصة"}</span>
            <h2>{isRegister ? <>اعمل حسابك <em>بسهولة</em></> : <>دخول الطلاب <em>والإدارة</em></>}</h2>
            <p>{isRegister ? "أنشئ حسابًا مجانيًا باسم مستخدم وكلمة مرور؛ وأكمل بيانات صفك الدراسي." : "استخدم اسم المستخدم وكلمة المرور. حساب الأدمن يفتح لوحة إدارة المنصة بعد الدخول."}</p>
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>
            {isRegister && (
              <label className="auth-field">
                <span>الاسم الذي سيظهر في حسابك</span>
                <input
                  type="text"
                  autoComplete="name"
                  minLength={2}
                  maxLength={80}
                  placeholder="مثال: مريم أحمد"
                  required
                  value={displayName}
                  onChange={(event) => setDisplayName(event.target.value)}
                />
              </label>
            )}

            <label className="auth-field">
              <span>اسم المستخدم</span>
              <input
                type="text"
                autoComplete={isRegister ? "username" : "username"}
                autoCapitalize="none"
                spellCheck={false}
                minLength={3}
                maxLength={24}
                pattern="[A-Za-z][A-Za-z0-9._-]{2,23}"
                title="ابدأ بحرف إنجليزي، من 3 إلى 24 حرفًا أو رقمًا"
                placeholder="مثال: mariam.hanish"
                required
                value={username}
                onChange={(event) => setUsername(event.target.value.replace(/\s/g, ""))}
              />
              {isRegister && <small>بالإنجليزية: ابدأ بحرف، ويمكن استخدام الأرقام والنقطة والشرطة.</small>}
            </label>

            {isRegister && (
              <label className="auth-field">
                <span>المرحلة والصف الدراسي</span>
                <select value={grade} required onChange={(event) => setGrade(event.target.value)}>
                  <option value="" disabled>اختر صفك الدراسي</option>
                  {grades.map((item) => <option key={item} value={item}>{item}</option>)}
                </select>
              </label>
            )}

            <label className="auth-field">
              <span>كلمة المرور</span>
              <span className="auth-password-wrap">
                <input
                  type={passwordVisible ? "text" : "password"}
                  autoComplete={isRegister ? "new-password" : "current-password"}
                  minLength={isRegister ? 8 : 1}
                  maxLength={72}
                  placeholder={isRegister ? "٨ أحرف على الأقل" : "اكتب كلمة المرور"}
                  required
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                />
                <button type="button" onClick={() => setPasswordVisible((visible) => !visible)} aria-label={passwordVisible ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}>
                  {passwordVisible ? "إخفاء" : "إظهار"}
                </button>
              </span>
            </label>

            {isRegister && (
              <label className="auth-field">
                <span>تأكيد كلمة المرور</span>
                <input
                  type={passwordVisible ? "text" : "password"}
                  autoComplete="new-password"
                  minLength={8}
                  maxLength={72}
                  placeholder="اكتب كلمة المرور مرة أخرى"
                  required
                  value={confirmPassword}
                  onChange={(event) => setConfirmPassword(event.target.value)}
                />
              </label>
            )}

            {errorMessage && <p className="auth-message auth-error" role="alert">{errorMessage}</p>}
            {notice && <p className="auth-message auth-notice" role="status">{notice}</p>}

            <button className="auth-submit" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "لحظة واحدة..." : isRegister ? "إنشاء الحساب والدخول" : "دخول إلى حسابي"}
              <ArrowIcon />
            </button>
            <p className="auth-secure-note"><span>✓</span> كلمة المرور مشفّرة ولا تظهر لأحد داخل المنصة.</p>
          </form>

          <div className="auth-switch">
            {isRegister ? <>عندك حساب بالفعل؟ <Link href="/login">سجّل دخولك</Link></> : <>لسه ماعملتش حساب؟ <Link href="/register">أنشئ حساب طالب</Link></>}
          </div>
          <div className="auth-family-note"><span>✦</span> مساحة تعليمية لأبناء عائلة حنيش <span>✦</span></div>
        </div>
      </section>
    </main>
  );
}

export function DashboardClient({
  name,
  username,
  grade,
}: {
  name: string;
  username: string;
  grade: string;
}) {
  const [isSigningOut, setIsSigningOut] = useState(false);

  async function handleSignOut() {
    setIsSigningOut(true);
    await import("next-auth/react").then(({ signOut: authSignOut }) => authSignOut({ redirectTo: "/login" }));
  }

  return (
    <main className="student-dashboard" dir="rtl">
      <header className="dashboard-header">
        <BrandMark />
        <span className="dashboard-secure-badge"><i /> حساب خاص ومحمي</span>
        <button className="dashboard-logout" type="button" onClick={handleSignOut} disabled={isSigningOut}>{isSigningOut ? "جارٍ الخروج..." : "تسجيل الخروج"}</button>
      </header>
      <section className="dashboard-content">
        <div className="dashboard-welcome-card">
          <div className="dashboard-welcome-copy">
            <span className="auth-eyebrow"><i /> لوحة الطالب الشخصية</span>
            <h1>أهلًا يا <em>{name}</em> 👋</h1>
            <p>حسابك جاهز، ومشوارك الدراسي يبدأ من خطوتك الجاية.</p>
          </div>
          <span className="dashboard-big-mark">ح</span>
        </div>
        <div className="dashboard-profile-grid">
          <article className="dashboard-profile-card">
            <span className="dashboard-profile-icon">✦</span>
            <small>اسم المستخدم</small>
            <strong dir="ltr">@{username}</strong>
            <p>استخدمه مع كلمة مرورك في كل مرة تسجّل فيها الدخول.</p>
          </article>
          <article className="dashboard-profile-card">
            <span className="dashboard-profile-icon dashboard-profile-icon-peach">⌂</span>
            <small>صفك الدراسي</small>
            <strong>{grade}</strong>
            <p>اختر صفك من دليل المناهج للوصول إلى موادك الرسمية.</p>
          </article>
        </div>
        <div className="dashboard-next-step">
          <div><span className="auth-eyebrow"><i /> خطوتك التعليمية التالية</span><h2>اكتشف الكتب الرسمية <em>الخاصة بصفك</em></h2><p>ابحث عن صفك، واختار المادة والفصل الدراسي من المكتبة الرسمية.</p></div>
          <div className="dashboard-quick-links"><Link href="/curricula">افتح دليل المناهج <ArrowIcon /></Link><a href="https://studentbooks.moe.gov.eg/" target="_blank" rel="noreferrer">المكتبة الإلكترونية للوزارة <ArrowIcon left /></a></div>
        </div>
        <footer className="dashboard-footer"><Link href="/">المنصة التعليمية لأبناء عائلة حنيش</Link><span>معلومات حسابك لا تظهر للطلاب الآخرين.</span></footer>
      </section>
    </main>
  );
}
