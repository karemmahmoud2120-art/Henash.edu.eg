"use client";

import Image from "next/image";
import { useEffect, useState, type FormEvent } from "react";

type StageId = "primary" | "middle" | "secondary";
type IconName =
  | "book"
  | "calculator"
  | "flask"
  | "atom"
  | "language"
  | "globe"
  | "play"
  | "arrow"
  | "sparkles"
  | "cap"
  | "users"
  | "monitor"
  | "check"
  | "clock"
  | "chat"
  | "shield"
  | "menu"
  | "close"
  | "calendar"
  | "heart";

type Course = {
  name: string;
  description: string;
  lessons: string;
  icon: IconName;
  tone: string;
};

type Stage = {
  id: StageId;
  label: string;
  shortLabel: string;
  grades: string;
  detail: string;
  icon: IconName;
  tone: string;
  courses: Course[];
};

const stages: Stage[] = [
  {
    id: "primary",
    label: "المرحلة الابتدائية",
    shortLabel: "ابتدائي",
    grades: "من الصف الأول إلى السادس",
    detail: "أساس قوي وحبّ للتعلّم من أول خطوة.",
    icon: "book",
    tone: "sage",
    courses: [
      { name: "اللغة العربية", description: "قراءة وقواعد وتعبير بأسلوب ممتع.", lessons: "٣٦ درسًا", icon: "language", tone: "peach" },
      { name: "الرياضيات", description: "نفهم المسائل خطوةً خطوة ونحلّ بثقة.", lessons: "٤٢ درسًا", icon: "calculator", tone: "blue" },
      { name: "العلوم", description: "نكتشف العالم من حولنا بالتجربة والسؤال.", lessons: "٢٨ درسًا", icon: "flask", tone: "green" },
      { name: "اللغة الإنجليزية", description: "كلمات ومحادثة وقواعد تناسب كل مستوى.", lessons: "٣٢ درسًا", icon: "globe", tone: "lavender" },
    ],
  },
  {
    id: "middle",
    label: "المرحلة الإعدادية",
    shortLabel: "إعدادي",
    grades: "من الصف الأول إلى الثالث الإعدادي",
    detail: "نرتّب الأفكار ونقوّي المهارات لكل مادة.",
    icon: "flask",
    tone: "blue",
    courses: [
      { name: "اللغة العربية", description: "نحو وقراءة ونصوص وتعبير مع تدريبات.", lessons: "٤٠ درسًا", icon: "language", tone: "peach" },
      { name: "الرياضيات", description: "جبر وهندسة ومسائل بشرح واضح.", lessons: "٤٨ درسًا", icon: "calculator", tone: "blue" },
      { name: "العلوم", description: "مفاهيم علمية مترابطة وتجارب مبسّطة.", lessons: "٣٦ درسًا", icon: "flask", tone: "green" },
      { name: "الدراسات الاجتماعية", description: "تاريخ وجغرافيا في خريطة واحدة.", lessons: "٣٠ درسًا", icon: "globe", tone: "lavender" },
    ],
  },
  {
    id: "secondary",
    label: "المرحلة الثانوية",
    shortLabel: "ثانوي",
    grades: "من الصف الأول إلى الثالث الثانوي",
    detail: "استعداد جاد للامتحانات ومشوار الجامعة.",
    icon: "atom",
    tone: "peach",
    courses: [
      { name: "الفيزياء", description: "نفهم القوانين ونطبّقها على أفكار الامتحان.", lessons: "٤٤ درسًا", icon: "atom", tone: "blue" },
      { name: "الكيمياء", description: "شرح مبسّط للمعادلات والتفاعلات المهمة.", lessons: "٣٨ درسًا", icon: "flask", tone: "green" },
      { name: "الأحياء", description: "رسومات توضيحية ومراجعة لكل وحدة.", lessons: "٣٤ درسًا", icon: "globe", tone: "lavender" },
      { name: "اللغة العربية", description: "نحو وبلاغة وأدب مع تطبيقات متنوعة.", lessons: "٤٠ درسًا", icon: "language", tone: "peach" },
    ],
  },
];

const features = [
  { icon: "cap" as const, title: "معلّمون يشرحون ببساطة", text: "خبرات تعليمية قريبة من الطالب وتتابع مستواه خطوة بخطوة." },
  { icon: "monitor" as const, title: "تعلّم في أي وقت", text: "دروس مسجّلة ترجع لها وقت ما تحتاج، من أي جهاز." },
  { icon: "calendar" as const, title: "متابعة تشجّعك", text: "خطة تعلّم واضحة واختبارات قصيرة لتعرف تقدّمك." },
];

function Icon({ name, size = 21, className }: { name: IconName; size?: number; className?: string }) {
  const shared = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className,
    "aria-hidden": true as const,
  };

  switch (name) {
    case "book":
      return <svg {...shared}><path d="M3.5 5.7c3.2-.9 5.9-.4 8.5 1.6v12c-2.6-2-5.3-2.5-8.5-1.6z" /><path d="M20.5 5.7c-3.2-.9-5.9-.4-8.5 1.6v12c2.6-2 5.3-2.5 8.5-1.6z" /><path d="M12 7.5v11.8" /></svg>;
    case "calculator":
      return <svg {...shared}><rect x="5" y="3" width="14" height="18" rx="2.3" /><path d="M8.5 7.5h7M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 16h.01M12 16h.01M15.5 16h.01" /></svg>;
    case "flask":
      return <svg {...shared}><path d="M9 3h6M10 3v6.2l-5.4 8.4A2.2 2.2 0 0 0 6.5 21h11a2.2 2.2 0 0 0 1.9-3.4L14 9.2V3" /><path d="M7.8 15h8.4M9.5 12.2h5" /></svg>;
    case "atom":
      return <svg {...shared}><circle cx="12" cy="12" r="1.3" /><ellipse cx="12" cy="12" rx="9" ry="3.7" transform="rotate(32 12 12)" /><ellipse cx="12" cy="12" rx="9" ry="3.7" transform="rotate(-32 12 12)" /></svg>;
    case "language":
      return <svg {...shared}><circle cx="12" cy="12" r="9" /><path d="M3.5 9h17M3.5 15h17M12 3c2.2 2.4 3.2 5.4 3.2 9s-1 6.6-3.2 9c-2.2-2.4-3.2-5.4-3.2-9s1-6.6 3.2-9Z" /></svg>;
    case "globe":
      return <svg {...shared}><circle cx="12" cy="12" r="9" /><path d="M3.5 12h17M12 3c2.2 2.4 3.2 5.4 3.2 9s-1 6.6-3.2 9c-2.2-2.4-3.2-5.4-3.2-9s1-6.6 3.2-9Z" /></svg>;
    case "play":
      return <svg {...shared}><circle cx="12" cy="12" r="9.2" /><path d="m10 8.5 5.3 3.5-5.3 3.5z" fill="currentColor" stroke="none" /></svg>;
    case "arrow":
      return <svg {...shared}><path d="M19 12H5M12 19l-7-7 7-7" /></svg>;
    case "sparkles":
      return <svg {...shared}><path d="m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5z" /><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z" /></svg>;
    case "cap":
      return <svg {...shared}><path d="m2.5 9 9.5-5 9.5 5-9.5 5z" /><path d="M6.5 11v5c3.2 2.5 7.8 2.5 11 0v-5M21.5 9v6" /></svg>;
    case "users":
      return <svg {...shared}><path d="M16 20v-1.5a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4V20" /><circle cx="9.5" cy="7" r="3.5" /><path d="M17 11a3.5 3.5 0 0 0 0-7M21 20v-1.5a4 4 0 0 0-3-3.9" /></svg>;
    case "monitor":
      return <svg {...shared}><rect x="3" y="4" width="18" height="13" rx="2" /><path d="M8 21h8M12 17v4M9 10l2 2 4-4" /></svg>;
    case "check":
      return <svg {...shared}><path d="m5 12.5 4.3 4L19 7" /></svg>;
    case "clock":
      return <svg {...shared}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></svg>;
    case "chat":
      return <svg {...shared}><path d="M20 11.5a7.8 7.8 0 0 1-8 7.5 8.3 8.3 0 0 1-3.4-.7L4 20l1.5-3.7A7.2 7.2 0 0 1 4 11.5 7.8 7.8 0 0 1 12 4a7.8 7.8 0 0 1 8 7.5Z" /><path d="M8 12h.01M12 12h.01M16 12h.01" /></svg>;
    case "shield":
      return <svg {...shared}><path d="M12 3 20 6v5.5c0 4.7-3.2 7.8-8 9.5-4.8-1.7-8-4.8-8-9.5V6z" /><path d="m8.5 12 2.3 2.3 4.8-5" /></svg>;
    case "calendar":
      return <svg {...shared}><rect x="3.5" y="5" width="17" height="16" rx="2" /><path d="M7.5 3v4M16.5 3v4M3.5 9.5h17M8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01" /></svg>;
    case "menu":
      return <svg {...shared}><path d="M4 7h16M4 12h16M4 17h16" /></svg>;
    case "close":
      return <svg {...shared}><path d="m6 6 12 12M18 6 6 18" /></svg>;
    case "heart":
      return <svg {...shared}><path d="M20.8 8.7c0 5.5-8.8 11-8.8 11s-8.8-5.5-8.8-11A4.6 4.6 0 0 1 12 6.2a4.6 4.6 0 0 1 8.8 2.5Z" /></svg>;
  }
}

function Brand() {
  return (
    <a className="brand" href="#home" aria-label="المنصة التعليمية لأبناء عائلة حنيش - الرئيسية">
      <span className="brand-mark"><span>ح</span><i /></span>
      <span className="brand-copy"><strong>حنيش</strong><small>منصة تعليمية</small></span>
    </a>
  );
}

export default function HomeClient() {
  const [activeStage, setActiveStage] = useState<StageId>("primary");
  const [isEnrollOpen, setIsEnrollOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [form, setForm] = useState({ studentName: "", guardianName: "", phone: "", stage: "ابتدائية", note: "" });
  const [submitState, setSubmitState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const selectedStage = stages.find((stage) => stage.id === activeStage) ?? stages[0];

  useEffect(() => {
    if (!isEnrollOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIsEnrollOpen(false);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isEnrollOpen]);

  function scrollToCourses(stageId?: StageId) {
    if (stageId) {
      const stage = stages.find((item) => item.id === stageId);
      if (stage) setActiveStage(stage.id);
    }
    document.getElementById("courses")?.scrollIntoView({ behavior: "smooth" });
  }

  function openEnrollment(stageId: StageId = activeStage) {
    const stage = stages.find((item) => item.id === stageId) ?? stages[0];
    setForm((current) => ({ ...current, stage: stage.shortLabel }));
    setSubmitState("idle");
    setErrorMessage("");
    setIsEnrollOpen(true);
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitState("loading");
    setErrorMessage("");
    try {
      const response = await fetch("/api/enrollments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const result = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(result.message || "تعذّر إرسال الطلب. حاول مرة أخرى.");
      setSubmitState("success");
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "حدث خطأ غير متوقع. حاول مرة أخرى.");
      setSubmitState("error");
    }
  }

  return (
    <div className="app-frame" dir="rtl">
      <div className="announcement">
        <div className="announcement-inner">
          <span className="announcement-message"><Icon name="sparkles" size={16} /> مساحة آمنة للتعلّم والنمو لكل أبناء عائلة حنيش</span>
          <a href="#about" className="announcement-link">اكتشف حكايتنا <Icon name="arrow" size={14} /></a>
        </div>
      </div>

      <header className="site-header">
        <div className="container header-inner">
          <Brand />
          <nav className={`main-nav ${mobileMenuOpen ? "is-open" : ""}`} aria-label="القائمة الرئيسية">
            <a href="#home" onClick={() => setMobileMenuOpen(false)}>الرئيسية</a>
            <a href="#stages" onClick={() => setMobileMenuOpen(false)}>المراحل الدراسية</a>
            <a href="/curricula" onClick={() => setMobileMenuOpen(false)}>المناهج الرسمية</a>
            <a href="#about" onClick={() => setMobileMenuOpen(false)}>مميزاتنا</a>
            <a href="#faq" onClick={() => setMobileMenuOpen(false)}>الأسئلة الشائعة</a>
            <a href="/register" onClick={() => setMobileMenuOpen(false)}>إنشاء حساب</a>
          </nav>
          <div className="header-actions">
            <a className="button button-small button-primary header-cta" href="/login">
              دخول الطلاب <Icon name="arrow" size={17} />
            </a>
            <button className="menu-toggle" onClick={() => setMobileMenuOpen((open) => !open)} aria-label={mobileMenuOpen ? "إغلاق القائمة" : "فتح القائمة"} aria-expanded={mobileMenuOpen}>
              <Icon name={mobileMenuOpen ? "close" : "menu"} size={22} />
            </button>
          </div>
        </div>
      </header>

      <main>
        <section className="hero-section" id="home">
          <div className="hero-deco hero-deco-one" />
          <div className="hero-deco hero-deco-two" />
          <div className="container hero-grid">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow-dot" /> معًا نحو مستقبل أجمل</div>
              <h1>كل خطوة في طريق العلم، <span>نخطوها معًا</span></h1>
              <p className="hero-description">منصة تعليمية تجمع أبناء عائلة حنيش على طريق التميّز، من أول سؤال في الابتدائي إلى حلم الجامعة.</p>
              <div className="hero-buttons">
                <button className="button button-primary" onClick={() => scrollToCourses()}>
                  اكتشف المراحل <Icon name="arrow" size={18} />
                </button>
                <button className="button button-video" onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}>
                  <span className="video-icon"><Icon name="play" size={19} /></span> كيف تعمل المنصة؟
                </button>
              </div>
              <div className="hero-trust">
                <div className="avatar-stack" aria-hidden="true"><span>م</span><span>ي</span><span>ع</span><span>+</span></div>
                <p><strong>كلنا في رحلة واحدة</strong><span>تعلّم، شارك، وكن فخورًا بتقدّمك</span></p>
              </div>
            </div>

            <div className="hero-visual" aria-label="طلاب من أبناء العائلة يذاكرون معًا">
              <div className="photo-frame">
                <Image src="/images/hanish-students.jpg" alt="أخ وأخته يذاكران معًا في أجواء منزلية مريحة" fill priority sizes="(max-width: 800px) 90vw, 48vw" />
                <div className="photo-gradient" />
                <div className="photo-caption"><span className="caption-sparkle"><Icon name="sparkles" size={17} /></span><span><strong>نتعلّم سويًا</strong><small>وننجح سويًا</small></span></div>
              </div>
              <div className="floating-card floating-progress">
                <span className="progress-icon"><Icon name="check" size={18} /></span>
                <span><strong>خطوة جديدة!</strong><small>تقدّمك يستحق الاحتفال</small></span>
              </div>
              <div className="floating-card floating-lessons">
                <span className="lessons-icon"><Icon name="play" size={19} /></span>
                <span><strong>دروس ممتعة</strong><small>تعلّم على راحتك</small></span>
              </div>
              <div className="visual-stamp"><Icon name="cap" size={25} /><span>علمٌ يجمعنا</span></div>
            </div>
          </div>
          <div className="container hero-bottom">
            <div className="hero-stat"><span className="stat-number">٣</span><span><strong>مراحل دراسية</strong><small>لكل الأعمار</small></span></div>
            <span className="stat-divider" />
            <div className="hero-stat"><span className="stat-number">١٢</span><span><strong>صفًا دراسيًا</strong><small>في دليل المناهج</small></span></div>
            <span className="stat-divider" />
            <div className="hero-stat"><span className="stat-number"><Icon name="users" size={24} /></span><span><strong>مجتمع واحد</strong><small>عائلة تتعلّم معًا</small></span></div>
            <a className="scroll-cue" href="#stages">اكتشف المنصة <span>↓</span></a>
          </div>
        </section>

        <section className="section stages-section" id="stages">
          <div className="container">
            <div className="section-heading">
              <div>
                <div className="eyebrow"><span className="eyebrow-dot" /> لكل مرحلة حكاية</div>
                <h2>من أول الدرس، <span>لأكبر حلم</span></h2>
              </div>
              <p>مهما كان صفك، هتلاقي مكانك هنا. اختار مرحلتك ووصل لكتب الوزارة ومصادرها الرسمية.</p>
            </div>
            <div className="stage-grid">
              {stages.map((stage, index) => (
                <button key={stage.id} className={`stage-card stage-${stage.tone} ${activeStage === stage.id ? "is-selected" : ""}`} onClick={() => scrollToCourses(stage.id)} aria-pressed={activeStage === stage.id}>
                  <div className="stage-card-top"><span className="stage-number">{["٠١", "٠٢", "٠٣"][index]}</span><span className="stage-icon"><Icon name={stage.icon} size={24} /></span></div>
                  <div className="stage-card-copy"><span className="stage-kicker">{stage.grades}</span><h3>{stage.label}</h3><p>{stage.detail}</p></div>
                  <span className="stage-card-link">استكشف المرحلة <Icon name="arrow" size={16} /></span>
                  <span className="stage-card-shape" aria-hidden="true" />
                </button>
              ))}
            </div>
          </div>
        </section>

        <section className="section courses-section" id="courses">
          <div className="container">
            <div className="courses-topline">
              <div className="section-heading courses-heading">
                <div><div className="eyebrow"><span className="eyebrow-dot" /> الكتب والمصادر الرسمية</div><h2>موادك، <span>من مصدرها</span></h2></div>
                <p>فهرس سريع للمواد الدراسية ومصادرها. تفاصيل المقرر الرسمي تتحدد حسب الصف والفصل والشعبة.</p>
              </div>
              <div className="stage-tabs" role="tablist" aria-label="اختيار المرحلة الدراسية">
                {stages.map((stage) => <button key={stage.id} className={activeStage === stage.id ? "active" : ""} onClick={() => setActiveStage(stage.id)} role="tab" aria-selected={activeStage === stage.id}>{stage.shortLabel}</button>)}
              </div>
            </div>
            <a className="official-curricula-card" href="/curricula">
              <span className="official-curricula-icon"><Icon name="book" size={21} /></span>
              <span className="official-curricula-copy"><strong>مناهج الوزارة لكل الصفوف</strong><small>من أولى ابتدائي إلى تالتة ثانوي، مع روابط الكتب الرسمية.</small></span>
              <span className="official-curricula-link">تصفّح الفهرس <Icon name="arrow" size={15} /></span>
            </a>
            <div className="courses-intro"><span className="active-stage-dot" /><strong>{selectedStage.label}</strong><span>{selectedStage.grades}</span></div>
            <div className="course-grid" key={activeStage}>
              {selectedStage.courses.map((course, index) => (
                <article className="course-card" key={course.name}>
                  <div className="course-card-head"><span className={`course-icon tone-${course.tone}`}><Icon name={course.icon} size={22} /></span><span className="course-lessons"><Icon name="book" size={14} /> كتاب الوزارة</span></div>
                  <div className="course-card-body"><span className="course-label">{selectedStage.shortLabel} · اختر صفك للدقة</span><h3>{course.name}</h3><p>{course.description}</p></div>
                  <div className="course-card-foot"><span><span className="lesson-dot" />كتاب ومقررات</span><a href="/curricula" aria-label={`استعرض المنهج الرسمي لمادة ${course.name}`}>عرض المنهج <Icon name="arrow" size={16} /></a></div>
                  <span className="course-index">{["٠١", "٠٢", "٠٣", "٠٤"][index]}</span>
                </article>
              ))}
            </div>
            <div className="courses-note"><Icon name="shield" size={19} /><span>أسماء المواد والمقررات تختلف حسب الصف والفصل والشعبة؛ افتح دليل المناهج للروابط الرسمية.</span></div>
          </div>
        </section>

        <section className="section about-section" id="about">
          <div className="container about-layout">
            <div className="about-art">
              <div className="about-card">
                <div className="about-card-top"><span className="about-card-icon"><Icon name="sparkles" size={21} /></span><span>رحلتك التعليمية</span><span className="about-live"><i /> مستمرة</span></div>
                <div className="about-card-title">كل يوم، <span>خطوة لقدّام</span></div>
                <div className="learning-path"><span className="path-line" /><div className="path-step done"><span><Icon name="check" size={14} /></span><div><strong>افهم الأساسيات</strong><small>ابدأ من حيث أنت</small></div></div><div className="path-step done"><span><Icon name="check" size={14} /></span><div><strong>تدرّب بثقة</strong><small>طبّق اللي اتعلّمته</small></div></div><div className="path-step current"><span>٣</span><div><strong>حقّق هدفك</strong><small>خطوتك القادمة أقرب</small></div></div></div>
                <div className="about-card-footer"><span><Icon name="clock" size={16} /> على راحتك، في أي وقت</span><span>✦</span></div>
              </div>
              <div className="about-sticker">مع بعض<br /><strong>أقوى</strong></div>
              <span className="about-orbit orbit-one" /><span className="about-orbit orbit-two" />
            </div>
            <div className="about-copy">
              <div className="eyebrow"><span className="eyebrow-dot" /> أكثر من مجرّد دروس</div>
              <h2>مكان يشجّعك <span>تكون أحسن</span></h2>
              <p className="about-lead">لأن التعلّم رحلة، عملنا مساحة تجمع العلم بالدعم، وتحوّل كل درس صغير لخطوة كبيرة نحو المستقبل.</p>
              <div className="feature-list">
                {features.map((feature) => <div className="feature-item" key={feature.title}><span className="feature-icon"><Icon name={feature.icon} size={21} /></span><div><h3>{feature.title}</h3><p>{feature.text}</p></div></div>)}
              </div>
              <button className="button button-primary" onClick={() => openEnrollment()}>سجّل وابدأ رحلتك <Icon name="arrow" size={18} /></button>
            </div>
          </div>
        </section>

        <section className="section how-section">
          <div className="container">
            <div className="how-heading"><div className="eyebrow"><span className="eyebrow-dot" /> البداية أسهل مما تتخيّل</div><h2>ثلاث خطوات، <span>وتبدأ الحكاية</span></h2><p>خليك على طبيعتك، وسيب الباقي علينا.</p></div>
            <div className="steps-grid">
              <div className="step-card"><span className="step-no">01</span><span className="step-icon"><Icon name="users" size={23} /></span><h3>سجّل بياناتك</h3><p>اكتب بياناتك وبيانات ولي أمرك لنتواصل معكم.</p></div>
              <div className="step-card"><span className="step-no">02</span><span className="step-icon"><Icon name="book" size={23} /></span><h3>اختار مرحلتك</h3><p>حدّد مرحلتك الدراسية والمواد التي تهمّك.</p></div>
              <div className="step-card"><span className="step-no">03</span><span className="step-icon"><Icon name="sparkles" size={23} /></span><h3>ابدأ وتقدّم</h3><p>اكتشف الدروس وتعلّم بالسرعة التي تناسبك.</p></div>
            </div>
          </div>
        </section>

        <section className="faq-section section" id="faq">
          <div className="container faq-layout">
            <div className="faq-intro"><div className="eyebrow"><span className="eyebrow-dot" /> عندك سؤال؟</div><h2>إجابات تخلّي الصورة <span>أوضح</span></h2><p>كل اللي محتاج تعرفه قبل ما تبدأ.</p><a href="#contact">لسه محتاج مساعدة؟ <Icon name="arrow" size={16} /></a></div>
            <div className="faq-list">
              <details open><summary>مين يقدر يستخدم المنصة؟ <span>+</span></summary><p>المنصة موجّهة لأبناء عائلة حنيش في المراحل الابتدائية والإعدادية والثانوية، مع محتوى يناسب كل مرحلة.</p></details>
              <details><summary>إزاي أسجّل ابني أو بنتي؟ <span>+</span></summary><p>اضغط «ابدأ رحلتك»، واملأ بيانات الطالب وولي الأمر والمرحلة الدراسية. فريق المنصة سيتواصل معكم لتوضيح الخطوات التالية.</p></details>
              <details><summary>هل أقدر أرجع للدرس أكتر من مرة؟ <span>+</span></summary><p>نعم، الدروس المسجّلة تتيح للطالب إعادة الشرح والمراجعة وقت ما يحتاج، وبالسرعة المناسبة له.</p></details>
              <details><summary>هل الدروس مناسبة لكل المستويات؟ <span>+</span></summary><p>نبدأ من المفاهيم الأساسية ثم ننتقل للتطبيق والتدريب، حتى يجد كل طالب طريقة مناسبة لمستواه.</p></details>
            </div>
          </div>
        </section>

        <section className="final-cta" id="contact">
          <div className="container final-cta-inner"><div className="cta-decoration"><Icon name="cap" size={48} /></div><div><span className="cta-kicker">حان وقت البداية</span><h2>المستقبل يبدأ <span>بخطوة منك</span></h2><p>سجّل اهتمامك، وخلّينا نبدأ الرحلة سوا.</p></div><button className="button button-cream" onClick={() => openEnrollment()}>ابدأ رحلتك الآن <Icon name="arrow" size={18} /></button><span className="cta-sparkle cta-sparkle-one">✳</span><span className="cta-sparkle cta-sparkle-two">✦</span></div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-main">
          <div className="footer-brand"><Brand /><p>علمٌ يجمعنا، وخطواتنا معًا تقرّبنا من أحلامنا.</p></div>
          <div className="footer-links"><strong>روابط سريعة</strong><a href="#stages">المراحل الدراسية</a><a href="/curricula">المناهج الرسمية</a><a href="#courses">المواد التعليمية</a><a href="#about">مميزاتنا</a></div>
          <div className="footer-links"><strong>لأنك تهمّنا</strong><a href="#faq">الأسئلة الشائعة</a><a href="#contact">التواصل والتسجيل</a><a href="/admin">إدارة المنصة</a></div>
          <div className="footer-note"><span className="footer-note-icon"><Icon name="heart" size={19} /></span><p>مساحة تعليمية<br /><strong>من العائلة، وللعائلة</strong></p></div>
        </div>
        <div className="container footer-bottom"><span>© {new Date().getFullYear()} المنصة التعليمية لأبناء عائلة حنيش</span><span>معًا نتعلّم، ومعًا ننجح <span className="footer-heart">♥</span></span></div>
      </footer>

      {isEnrollOpen && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setIsEnrollOpen(false); }}>
          <section className="enroll-modal" role="dialog" aria-modal="true" aria-labelledby="enroll-title">
            <button className="modal-close" onClick={() => setIsEnrollOpen(false)} aria-label="إغلاق نافذة التسجيل"><Icon name="close" size={20} /></button>
            {submitState === "success" ? (
              <div className="success-state"><span className="success-icon"><Icon name="check" size={29} /></span><span className="eyebrow"><span className="eyebrow-dot" /> وصلت رسالتك بنجاح</span><h2 id="enroll-title">أهلًا بك <span>في الرحلة!</span></h2><p>تم تسجيل طلبك، وسيتواصل فريق المنصة مع ولي أمرك قريبًا لإكمال الخطوات.</p><button className="button button-primary" onClick={() => setIsEnrollOpen(false)}>العودة للمنصة <Icon name="arrow" size={18} /></button></div>
            ) : (
              <>
                <div className="modal-heading"><span className="modal-mark"><Icon name="cap" size={23} /></span><span className="eyebrow"><span className="eyebrow-dot" /> خطوة أولى نحو التميّز</span><h2 id="enroll-title">ابدأ رحلتك <span>التعليمية</span></h2><p>اكتب بياناتك وسنتواصل مع ولي أمرك لتوضيح التفاصيل.</p></div>
                <form className="enroll-form" onSubmit={handleSubmit}>
                  <label>اسم الطالب أو الطالبة<input required minLength={2} maxLength={120} autoComplete="name" placeholder="الاسم بالكامل" value={form.studentName} onChange={(event) => setForm({ ...form, studentName: event.target.value })} /></label>
                  <label>اسم ولي الأمر<input required minLength={2} maxLength={120} autoComplete="name" placeholder="اسم ولي الأمر" value={form.guardianName} onChange={(event) => setForm({ ...form, guardianName: event.target.value })} /></label>
                  <label>رقم هاتف ولي الأمر<input required type="tel" inputMode="tel" autoComplete="tel" placeholder="01xxxxxxxxx" value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} /></label>
                  <label>المرحلة الدراسية<select value={form.stage} onChange={(event) => setForm({ ...form, stage: event.target.value })}><option value="ابتدائي">المرحلة الابتدائية</option><option value="إعدادي">المرحلة الإعدادية</option><option value="ثانوي">المرحلة الثانوية</option></select></label>
                  <label className="form-full">رسالة أو مادة تهمّك <span className="optional-label">(اختياري)</span><textarea maxLength={1000} rows={3} placeholder="اكتب أي تفاصيل تحب نعرفها..." value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} /></label>
                  {submitState === "error" && <p className="form-error" role="alert">{errorMessage}</p>}
                  <button className="button button-primary form-submit" type="submit" disabled={submitState === "loading"}>{submitState === "loading" ? "جارٍ إرسال طلبك..." : "إرسال طلب التسجيل"}<Icon name="arrow" size={18} /></button>
                  <p className="form-privacy"><Icon name="shield" size={15} /> بياناتك محفوظة وتُستخدم للتواصل بخصوص التسجيل فقط.</p>
                </form>
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
}

