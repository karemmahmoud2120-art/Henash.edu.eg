import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "المنصة التعليمية لأبناء عائلة حنيش",
  description: "منصة تعليمية تجمع أبناء عائلة حنيش على طريق التميز، لطلاب المرحلة الابتدائية والإعدادية والثانوية.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
