import { db } from "@/db";
import { isSameOriginRequest } from "@/lib/auth-security";
import { studentRequests } from "@/db/schema";

const allowedStages = new Set(["ابتدائي", "إعدادي", "ثانوي"]);

export async function POST(request: Request) {
  if (!isSameOriginRequest(request)) {
    return Response.json({ message: "تعذّر التحقق من مصدر الطلب." }, { status: 403 });
  }
  if (Number(request.headers.get("content-length") ?? 0) > 8192) {
    return Response.json({ message: "حجم الطلب أكبر من المسموح." }, { status: 413 });
  }
  if (!request.headers.get("content-type")?.toLowerCase().includes("application/json")) {
    return Response.json({ message: "صيغة الطلب غير صالحة." }, { status: 415 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ message: "بيانات الطلب غير صالحة." }, { status: 400 });
  }

  if (!body || typeof body !== "object") {
    return Response.json({ message: "بيانات الطلب غير صالحة." }, { status: 400 });
  }

  const payload = body as Record<string, unknown>;
  const studentName = typeof payload.studentName === "string" ? payload.studentName.trim() : "";
  const guardianName = typeof payload.guardianName === "string" ? payload.guardianName.trim() : "";
  const phone = typeof payload.phone === "string" ? payload.phone.trim() : "";
  const stage = typeof payload.stage === "string" ? payload.stage.trim() : "";
  const note = typeof payload.note === "string" ? payload.note.trim() : "";
  const digitsOnly = phone.replace(/\D/g, "");

  if (studentName.length < 2 || studentName.length > 120) {
    return Response.json({ message: "من فضلك اكتب اسم الطالب بشكل صحيح." }, { status: 400 });
  }
  if (guardianName.length < 2 || guardianName.length > 120) {
    return Response.json({ message: "من فضلك اكتب اسم ولي الأمر بشكل صحيح." }, { status: 400 });
  }
  if (digitsOnly.length < 10 || digitsOnly.length > 15 || phone.length > 30) {
    return Response.json({ message: "من فضلك اكتب رقم هاتف صحيحًا." }, { status: 400 });
  }
  if (!allowedStages.has(stage)) {
    return Response.json({ message: "من فضلك اختر مرحلة دراسية صحيحة." }, { status: 400 });
  }
  if (note.length > 1000) {
    return Response.json({ message: "الرسالة طويلة جدًا." }, { status: 400 });
  }

  try {
    const [createdRequest] = await db
      .insert(studentRequests)
      .values({ studentName, guardianName, phone, stage, note: note || null })
      .returning({ id: studentRequests.id });

    return Response.json({ ok: true, requestId: createdRequest.id }, { status: 201 });
  } catch (error) {
    console.error("Unable to save student enrollment request", error);
    return Response.json({ message: "حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى." }, { status: 500 });
  }
}
