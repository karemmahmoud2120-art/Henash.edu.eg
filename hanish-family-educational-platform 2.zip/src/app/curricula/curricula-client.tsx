"use client";

import "./curricula.css";
import Link from "next/link";
import { useMemo, useState } from "react";

type StageId = "primary" | "preparatory" | "secondary";
type SchoolTrack = "science" | "math" | "literary";
type SubjectGroup = {
  id: string;
  title: string;
  gradeTitle: string;
  subjects: string[];
  commonSubjects?: string[];
  tracks?: Partial<Record<SchoolTrack, string[]>>;
  assessmentNote?: string;
};

const stages: { id: StageId; title: string; short: string; range: string }[] = [
  { id: "primary", title: "المرحلة الابتدائية", short: "ابتدائي", range: "الصف الأول – السادس" },
  { id: "preparatory", title: "المرحلة الإعدادية", short: "إعدادي", range: "الصف الأول – الثالث" },
  { id: "secondary", title: "المرحلة الثانوية", short: "ثانوي", range: "الصف الأول – الثالث" },
];

const primaryOrdinals = ["الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس"];
const prepOrdinals = ["الأول", "الثاني", "الثالث"];

const primaryLowerSubjects = [
  "اللغة العربية",
  "اللغة الإنجليزية",
  "الرياضيات",
  "اكتشف / متعدد التخصصات",
  "التربية الدينية (الإسلامية أو المسيحية)",
];
const primaryUpperSubjects = [
  "اللغة العربية",
  "اللغة الإنجليزية",
  "الرياضيات",
  "العلوم",
  "الدراسات الاجتماعية",
  "التربية الدينية (الإسلامية أو المسيحية)",
  "تكنولوجيا المعلومات والاتصالات",
  "المهارات المهنية",
];
const preparatorySubjects = [
  "اللغة العربية",
  "اللغة الإنجليزية",
  "الرياضيات",
  "العلوم",
  "الدراسات الاجتماعية",
  "التربية الدينية (الإسلامية أو المسيحية)",
  "تكنولوجيا المعلومات والاتصالات",
];
const secondaryCommonSubjects = [
  "التربية الدينية",
  "اللغة الأجنبية الثانية",
  "التربية الرياضية",
  "التربية الوطنية",
];

const groups: SubjectGroup[] = [
  ...primaryOrdinals.map((ordinal, index) => ({
    id: `primary-${index + 1}`,
    title: `الصف ${ordinal} الابتدائي`,
    gradeTitle: `${ordinal} ابتدائي`,
    subjects: index < 3 ? primaryLowerSubjects : primaryUpperSubjects,
  })),
  ...prepOrdinals.map((ordinal, index) => ({
    id: `preparatory-${index + 1}`,
    title: `الصف ${ordinal} الإعدادي`,
    gradeTitle: `${ordinal} إعدادي`,
    subjects: preparatorySubjects,
  })),
  {
    id: "secondary-1",
    title: "الصف الأول الثانوي",
    gradeTitle: "الأول الثانوي",
    subjects: [
      "اللغة العربية",
      "اللغة الأجنبية الأولى",
      "الرياضيات",
      "العلوم المتكاملة",
      "التاريخ",
      "الفلسفة والمنطق",
    ],
    commonSubjects: [
      "التربية الدينية",
      "اللغة الأجنبية الثانية",
      "التربية الرياضية",
      "البرمجة والذكاء الاصطناعي",
    ],
    assessmentNote:
      "تعرض البوابة الرسمية مواد كتاب الطالب والتقييمات. تصنيف المادة إلى مضافة للمجموع أو نجاح ورسوب يُراجع وفق القرار الوزاري والنظام الدراسي المسجّل للطالب.",
  },
  {
    id: "secondary-2",
    title: "الصف الثاني الثانوي",
    gradeTitle: "الثاني الثانوي",
    subjects: [],
    commonSubjects: secondaryCommonSubjects,
    tracks: {
      science: [
        "اللغة العربية",
        "اللغة الأجنبية الأولى",
        "الرياضيات",
        "التاريخ",
        "الكيمياء",
        "الفيزياء",
      ],
      literary: [
        "اللغة العربية",
        "اللغة الأجنبية الأولى",
        "التاريخ",
        "الجغرافيا",
        "علم النفس",
        "الرياضيات",
      ],
    },
    assessmentNote:
      "وفق نظام الثانوية العامة المنشور للعام الدراسي 2025–2026. اختر الشعبة لعرض موادها؛ النسخة النهائية ومقررات كل طالب تُراجع من كتاب الوزارة والمدرسة.",
  },
  {
    id: "secondary-3",
    title: "الصف الثالث الثانوي",
    gradeTitle: "الثالث الثانوي",
    subjects: [],
    commonSubjects: secondaryCommonSubjects,
    tracks: {
      science: [
        "اللغة العربية",
        "اللغة الأجنبية الأولى",
        "الأحياء",
        "الكيمياء",
        "الفيزياء",
      ],
      math: [
        "اللغة العربية",
        "اللغة الأجنبية الأولى",
        "الرياضيات",
        "الكيمياء",
        "الفيزياء",
      ],
      literary: [
        "اللغة العربية",
        "اللغة الأجنبية الأولى",
        "التاريخ",
        "الجغرافيا",
        "الإحصاء",
      ],
    },
    assessmentNote:
      "مواد الثانوية العامة تختلف حسب الشعبة؛ بعض المدارس والطلاب قد يتبعون نظامًا تعليميًا آخر. استخدم المكتبة الرسمية واختر نظامك وشعبتك قبل تنزيل الكتاب.",
  },
];

const trackOptions: { id: SchoolTrack; label: string }[] = [
  { id: "science", label: "علمي علوم" },
  { id: "math", label: "علمي رياضة" },
  { id: "literary", label: "أدبي" },
];

const ministryBooksUrl = "https://studentbooks.moe.gov.eg/";
const eLearningUrl = "https://moe.gov.eg/ar/elearningenterypage/e-learning/";
const secondaryDecisionUrl = "https://moe.gov.eg/ar/what-s-on/news/17-9-25-1/";
const secondaryBooksNewsUrl = "https://moe.gov.eg/ar/what-s-on/news/9-9-25/";

function BookIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M3.5 5.7c3.2-.9 5.9-.4 8.5 1.6v12c-2.6-2-5.3-2.5-8.5-1.6z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
      <path d="M20.5 5.7c-3.2-.9-5.9-.4-8.5 1.6v12c2.6-2 5.3-2.5 8.5-1.6z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
      <path d="M12 7.5v11.8" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

function ArrowIcon({ external = false }: { external?: boolean }) {
  return external ? (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M14 4h6v6M20 4l-9 9M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ) : (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M19 12H5m7 7-7-7 7-7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Logo() {
  return (
    <Link className="brand curricula-brand" href="/" aria-label="العودة إلى الصفحة الرئيسية">
      <span className="brand-mark"><span>ح</span><i /></span>
      <span className="brand-copy"><strong>حنيش</strong><small>منصة تعليمية</small></span>
    </Link>
  );
}

export default function CurriculaClient() {
  const [activeStage, setActiveStage] = useState<StageId | "all">("all");
  const [selectedId, setSelectedId] = useState(groups[0].id);
  const [track, setTrack] = useState<SchoolTrack>("science");
  const [search, setSearch] = useState("");

  const filteredGroups = useMemo(() => {
    const normalizedSearch = search.trim().toLocaleLowerCase("ar");
    return groups.filter((group) => {
      const matchesStage = activeStage === "all" || group.id.startsWith(`${activeStage}-`);
      const searchable = `${group.title} ${group.subjects.join(" ")} ${group.commonSubjects?.join(" ") ?? ""} ${Object.values(group.tracks ?? {}).flat().join(" ")}`.toLocaleLowerCase("ar");
      return matchesStage && (!normalizedSearch || searchable.includes(normalizedSearch));
    });
  }, [activeStage, search]);

  const selectedGroup = filteredGroups.find((group) => group.id === selectedId) ?? filteredGroups[0];
  const hasTracks = Boolean(selectedGroup?.tracks);
  const chosenTrack = hasTracks && selectedGroup?.tracks?.[track] ? track : (hasTracks ? (Object.keys(selectedGroup.tracks ?? {})[0] as SchoolTrack) : "science");
  const subjects = selectedGroup
    ? hasTracks
      ? [...(selectedGroup.tracks?.[chosenTrack] ?? []), ...(selectedGroup.commonSubjects ?? [])]
      : [...selectedGroup.subjects, ...(selectedGroup.commonSubjects ?? [])]
    : [];

  function chooseStage(stage: StageId | "all") {
    setActiveStage(stage);
    const firstMatch = groups.find((group) => stage === "all" || group.id.startsWith(`${stage}-`));
    if (firstMatch) setSelectedId(firstMatch.id);
    setSearch("");
  }

  function chooseGroup(id: string) {
    setSelectedId(id);
    setTrack("science");
  }

  return (
    <main className="curricula-page" dir="rtl">
      <header className="curricula-header">
        <div className="curricula-header-inner">
          <Logo />
          <nav className="curricula-nav" aria-label="التنقل">
            <Link href="/">الرئيسية</Link>
            <a className="curricula-nav-active" href="#grade-directory">دليل المناهج</a>
            <Link href="/register">إنشاء حساب</Link>
          </nav>
          <a className="curricula-header-button" href="/login">
            دخول الطالب <ArrowIcon />
          </a>
        </div>
      </header>

      <section className="curricula-hero">
        <div className="curricula-hero-pattern" aria-hidden="true" />
        <div className="curricula-container curricula-hero-grid">
          <div className="curricula-hero-copy">
            <Link className="curricula-breadcrumb" href="/">الرئيسية <span>←</span> دليل المناهج</Link>
            <span className="curricula-eyebrow"><span /> المنهج المصري · المكتبة الرسمية</span>
            <h1>منهجك الدراسي،<br /><em>من مصدره الصحيح.</em></h1>
            <p>دليل عملي لصفوف الابتدائي والإعدادي والثانوي. اختار صفك لتعرف المواد الأساسية وتصل مباشرةً إلى الكتب الإلكترونية الرسمية.</p>
            <a className="curricula-primary-button" href={ministryBooksUrl} target="_blank" rel="noreferrer">
              افتح مكتبة كتب الوزارة <ArrowIcon external />
            </a>
            <span className="curricula-academic-note"><span className="curricula-status-dot" /> آخر مكتبة رسمية تم التحقق منها: العام الدراسي 2025–2026</span>
          </div>
          <div className="curricula-hero-card">
            <div className="curricula-book-emblem"><BookIcon size={31} /></div>
            <div className="curricula-hero-card-label">دليل الصفوف الدراسية</div>
            <div className="curricula-grade-count">١٢ <span>صفًا</span></div>
            <div className="curricula-hero-divider" />
            <div className="curricula-hero-stages">
              <span><i className="grade-dot dot-primary" /> ٦ ابتدائي</span>
              <span><i className="grade-dot dot-preparatory" /> ٣ إعدادي</span>
              <span><i className="grade-dot dot-secondary" /> ٣ ثانوي</span>
            </div>
            <p>كل كتاب يوصلك لمصدر الوزارة؛ لا نسخ مجهولة ولا مناهج من سنوات مختلفة.</p>
            <span className="curricula-card-decoration" aria-hidden="true">✦</span>
          </div>
        </div>
      </section>

      <section className="curricula-content curricula-container" id="grade-directory">
        <div className="curricula-section-heading">
          <div>
            <span className="curricula-eyebrow"><span /> اختار مكانك من الخريطة</span>
            <h2>كل صفوفك <em>في مكان واحد</em></h2>
            <p>حدد المرحلة والصف؛ تظهر لك المواد الأساسية ورابط المصدر الرسمي.</p>
          </div>
          <div className="curricula-year-badge"><BookIcon size={17} /> المكتبة الرسمية 2025–2026</div>
        </div>

        <div className="curricula-browser">
          <div className="curricula-filter-bar">
            <div className="curricula-stage-tabs" role="tablist" aria-label="فلترة المناهج حسب المرحلة">
              <button className={activeStage === "all" ? "is-active" : ""} onClick={() => chooseStage("all")} role="tab" aria-selected={activeStage === "all"}>كل المراحل <span>١٢</span></button>
              {stages.map((stage) => {
                const count = groups.filter((group) => group.id.startsWith(`${stage.id}-`)).length;
                return (
                  <button key={stage.id} className={activeStage === stage.id ? "is-active" : ""} onClick={() => chooseStage(stage.id)} role="tab" aria-selected={activeStage === stage.id}>
                    {stage.short} <span>{count}</span>
                  </button>
                );
              })}
            </div>
            <label className="curricula-search">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.7" stroke="currentColor" strokeWidth="1.7" /><path d="m16 16 4.5 4.5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></svg>
              <input type="search" placeholder="ابحث عن صف أو مادة..." aria-label="ابحث عن صف أو مادة" value={search} onChange={(event) => setSearch(event.target.value)} />
            </label>
          </div>

          <div className="curricula-browser-layout">
            <aside className="grade-list" aria-label="قائمة الصفوف">
              {filteredGroups.length === 0 ? (
                <div className="curricula-empty">ما لقيناش صف أو مادة بالاسم ده. جرّب كلمة تانية.</div>
              ) : filteredGroups.map((group, index) => {
                const stage = stages.find((item) => group.id.startsWith(`${item.id}-`));
                const isSelected = selectedGroup?.id === group.id;
                return (
                  <button key={group.id} className={`grade-list-item ${isSelected ? "is-selected" : ""}`} onClick={() => chooseGroup(group.id)} aria-pressed={isSelected}>
                    <span className="grade-list-no">{String(index + 1).padStart(2, "0").replace(/[0-9]/g, (digit) => "٠١٢٣٤٥٦٧٨٩"[Number(digit)])}</span>
                    <span className="grade-list-copy"><strong>{group.title}</strong><small>{stage?.title}</small></span>
                    <span className="grade-list-arrow"><ArrowIcon /></span>
                  </button>
                );
              })}
            </aside>

            <div className="grade-detail" aria-live="polite">
              {selectedGroup ? (
                <>
                  <div className="grade-detail-top">
                    <div>
                      <span className="grade-detail-label"><span /> {stages.find((stage) => selectedGroup.id.startsWith(`${stage.id}-`))?.title}</span>
                      <h3>{selectedGroup.title}</h3>
                      <p>المواد والمقررات قد تتغير باختلاف الشعبة والسنة الدراسية؛ الكتاب الرسمي هو المرجع النهائي.</p>
                    </div>
                    <span className="grade-book-mark"><BookIcon size={25} /></span>
                  </div>

                  {hasTracks && (
                    <div className="curricula-track-control">
                      <label htmlFor="track-select">اختار الشعبة</label>
                      <select id="track-select" value={chosenTrack} onChange={(event) => setTrack(event.target.value as SchoolTrack)}>
                        {trackOptions.filter((option) => selectedGroup.tracks?.[option.id]).map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}
                      </select>
                    </div>
                  )}

                  <div className="subject-heading"><strong>مواد هذا الصف</strong><span>{subjects.length} مواد ومقررات</span></div>
                  <div className="curricula-subject-list">
                    {subjects.map((subject, index) => (
                      <span className={`curricula-subject-pill subject-${index % 4}`} key={`${selectedGroup.id}-${subject}`}>
                        <i /> {subject}
                      </span>
                    ))}
                  </div>
                  {selectedGroup.assessmentNote && (
                    <div className="curricula-grade-note"><span>!</span><p>{selectedGroup.assessmentNote}</p></div>
                  )}
                  {!hasTracks && <p className="curricula-subject-disclaimer">القائمة إرشادية للمواد الدراسية الشائعة في هذا الصف، وليست جدول توزيع دروس. راجع المكتبة الرسمية للتأكد من اسم الكتاب والمادة حسب الفصل الدراسي.</p>}
                  <div className="grade-actions">
                    <a className="grade-official-link" href={ministryBooksUrl} target="_blank" rel="noreferrer">تحميل / استعراض كتب الوزارة <ArrowIcon external /></a>
                    <a className="grade-secondary-link" href={eLearningUrl} target="_blank" rel="noreferrer">بوابة التعليم الإلكتروني <ArrowIcon external /></a>
                  </div>
                </>
              ) : (
                <div className="curricula-empty curricula-empty-detail">اختار صفًا من القائمة علشان تشوف مواده.</div>
              )}
            </div>
          </div>
        </div>

        <section className="curricula-how-to" aria-labelledby="curricula-how-title">
          <div className="curricula-how-intro">
            <span className="curricula-eyebrow"><span /> الطريق الرسمي في ٣ دقائق</span>
            <h2 id="curricula-how-title">إزاي توصل لكتاب <em>ابنك؟</em></h2>
            <p>الكتب متاحة على موقع الوزارة، والتفاصيل تختارها أنت عشان تطابق صف الطالب وفصله.</p>
            <a href={ministryBooksUrl} target="_blank" rel="noreferrer">ابدأ من المكتبة الإلكترونية <ArrowIcon external /></a>
          </div>
          <ol className="curricula-steps">
            <li><span className="step-number">١</span><div><strong>اختار المرحلة والصف</strong><p>ابتدائي أو إعدادي أو ثانوي، وبعدها الصف المطلوب.</p></div></li>
            <li><span className="step-number">٢</span><div><strong>حدد العام والفصل الدراسي</strong><p>تأكد أن الكتاب للعام 2025–2026 وللترم الذي تريده.</p></div></li>
            <li><span className="step-number">٣</span><div><strong>افتح المادة وحمّل الكتاب</strong><p>اضغط «استعراض» أو «تحميل» لحفظ ملف PDF الرسمي.</p></div></li>
          </ol>
        </section>

        <section className="curricula-source-card" aria-label="مصادر رسمية">
          <div className="source-mark"><BookIcon size={23} /></div>
          <div className="source-copy">
            <span>المصدر الأساسي: وزارة التربية والتعليم والتعليم الفني</span>
            <h2>المناهج من الوزارة، <em>مش من روابط عشوائية.</em></h2>
            <p>أكدت الوزارة إتاحة المكتبة الإلكترونية 2025–2026 وإتاحة مناهج المرحلة الثانوية على بوابتها الرسمية. هذا الفهرس يساعدك في الوصول ولا يستبدل كتاب الوزارة.</p>
            <div className="source-links">
              <a href={ministryBooksUrl} target="_blank" rel="noreferrer">المكتبة الإلكترونية 2025–2026 <ArrowIcon external /></a>
              <a href={secondaryBooksNewsUrl} target="_blank" rel="noreferrer">إعلان إتاحة كتب الثانوية <ArrowIcon external /></a>
              <a href={secondaryDecisionUrl} target="_blank" rel="noreferrer">القرار الوزاري لمواد الثانوية 2025/2026 <ArrowIcon external /></a>
            </div>
          </div>
        </section>

        <footer className="curricula-footer">
          <Logo />
          <span>المنصة التعليمية لأبناء عائلة حنيش · دليل مناهج مصر</span>
          <Link href="/">العودة إلى المنصة <ArrowIcon /></Link>
        </footer>
      </section>
    </main>
  );
}
