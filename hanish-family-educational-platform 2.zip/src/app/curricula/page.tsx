import type { Metadata } from "next";
import CurriculaClient from "./curricula-client";

export const metadata: Metadata = {
  title: "دليل مناهج الصفوف والكتب الرسمية | منصة حنيش التعليمية",
  description:
    "دليل مناهج المرحلة الابتدائية والإعدادية والثانوية في مصر للعام الدراسي 2025–2026، مع روابط المكتبة الإلكترونية الرسمية لوزارة التربية والتعليم.",
};

export default function CurriculaPage() {
  return <CurriculaClient />;
}
