import type { Metadata } from "next";
import AuthPage from "@/app/auth-ui";

export const metadata: Metadata = {
  title: "دخول الطالب | منصة حنيش التعليمية",
  description: "سجّل دخولك باسم المستخدم وكلمة المرور إلى حسابك في المنصة التعليمية لأبناء عائلة حنيش.",
};

export default function LoginPage() {
  return <AuthPage mode="login" />;
}
