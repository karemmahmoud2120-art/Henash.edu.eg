import bcrypt from "bcryptjs";
import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { platformUsers } from "@/db/schema";
import { enforceRateLimit } from "@/lib/auth-security";

const usernamePattern = /^[a-zA-Z][a-zA-Z0-9._-]{2,23}$/;
const loginWindowMilliseconds = 15 * 60 * 1000;
const dummyPasswordHash = bcrypt.hash("a-deliberately-invalid-password", 12);

export const { handlers, auth, signIn, signOut } = NextAuth({
  secret: process.env.AUTH_SECRET,
  trustHost: true,
  pages: {
    signIn: "/login",
  },
  session: {
    strategy: "jwt",
    maxAge: 14 * 24 * 60 * 60,
  },
  providers: [
    Credentials({
      id: "credentials",
      name: "اسم المستخدم وكلمة المرور",
      credentials: {
        username: { label: "اسم المستخدم", type: "text", maxLength: 24 },
        password: { label: "كلمة المرور", type: "password", maxLength: 72 },
      },
      async authorize(credentials, request) {
        const rawUsername = typeof credentials.username === "string" ? credentials.username.trim() : "";
        const username = rawUsername.toLowerCase();
        const password = typeof credentials.password === "string" ? credentials.password : "";
        const validUsername = usernamePattern.test(rawUsername);
        const validPasswordLength = Buffer.byteLength(password, "utf8") <= 72;

        if (!validPasswordLength) {
          await bcrypt.compare("invalid-password", await dummyPasswordHash);
          return null;
        }

        const rateLimit = await enforceRateLimit({
          scope: "login",
          headers: request.headers,
          limit: 30,
          windowMilliseconds: loginWindowMilliseconds,
        });
        if (!rateLimit.allowed) return null;

        const [user] = validUsername
          ? await db
              .select({
                id: platformUsers.id,
                username: platformUsers.username,
                displayName: platformUsers.displayName,
                passwordHash: platformUsers.passwordHash,
                grade: platformUsers.grade,
                role: platformUsers.role,
                isActive: platformUsers.isActive,
              })
              .from(platformUsers)
              .where(eq(platformUsers.username, username))
              .limit(1)
          : [];

        const passwordMatches = await bcrypt.compare(password, user?.passwordHash ?? (await dummyPasswordHash));
        if (!user || !user.isActive || !passwordMatches) return null;

        return {
          id: String(user.id),
          name: user.displayName,
          username: user.username,
          grade: user.grade,
          role: user.role === "admin" ? "admin" as const : "student" as const,
        };
      },
    }),
  ],
  callbacks: {
    jwt({ token, user }) {
      if (user) {
        if (user.id) token.id = user.id;
        token.username = user.username;
        token.grade = user.grade;
        token.role = user.role;
      }
      return token;
    },
    async session({ session, token }) {
      if (!session.user) return session;

      const rawId = typeof token.id === "string" ? token.id : typeof token.sub === "string" ? token.sub : "";
      const id = Number(rawId);
      if (!Number.isSafeInteger(id) || id < 1) {
        session.user.id = "";
        session.user.username = "";
        session.user.grade = "";
        session.user.role = "student";
        return session;
      }

      const [account] = await db
        .select({ username: platformUsers.username, grade: platformUsers.grade, role: platformUsers.role, isActive: platformUsers.isActive })
        .from(platformUsers)
        .where(eq(platformUsers.id, id))
        .limit(1);

      if (!account || !account.isActive) {
        session.user.id = "";
        session.user.username = "";
        session.user.grade = "";
        session.user.role = "student";
        return session;
      }

      session.user.id = rawId;
      session.user.username = account.username;
      session.user.grade = account.grade;
      session.user.role = account.role === "admin" ? "admin" : "student";
      return session;
    },
  },
});
