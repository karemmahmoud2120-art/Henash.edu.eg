import { boolean, integer, pgTable, serial, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";

export const platformUsers = pgTable(
  "platform_users",
  {
    id: serial("id").primaryKey(),
    username: varchar("username", { length: 24 }).notNull(),
    displayName: varchar("display_name", { length: 80 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    grade: varchar("grade", { length: 50 }).notNull(),
    role: varchar("role", { length: 20 }).notNull().default("student"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("platform_users_username_unique").on(table.username)],
);

export const authRateLimits = pgTable(
  "auth_rate_limits",
  {
    id: serial("id").primaryKey(),
    key: varchar("key", { length: 64 }).notNull(),
    attempts: integer("attempts").notNull().default(0),
    windowStartedAt: timestamp("window_started_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("auth_rate_limits_key_unique").on(table.key)],
);

export const studentRequests = pgTable("student_requests", {
  id: serial("id").primaryKey(),
  studentName: varchar("student_name", { length: 120 }).notNull(),
  guardianName: varchar("guardian_name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  stage: varchar("stage", { length: 40 }).notNull(),
  note: text("note"),
  status: varchar("status", { length: 20 }).notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
