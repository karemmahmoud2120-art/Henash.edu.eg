import type { DefaultSession } from "next-auth";

export type PlatformRole = "student" | "admin";

declare module "next-auth" {
  interface User {
    username: string;
    grade: string;
    role: PlatformRole;
  }

  interface Session {
    user: {
      id: string;
      username: string;
      grade: string;
      role: PlatformRole;
    } & DefaultSession["user"];
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string;
    username?: string;
    grade?: string;
    role?: PlatformRole;
  }
}
